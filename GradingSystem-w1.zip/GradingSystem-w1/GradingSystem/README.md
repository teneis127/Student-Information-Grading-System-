# GradingSystem - Bước 1 (Grading schemes + tests)

## Dựng solution
```bash
dotnet new sln -n GradingSystem
dotnet new classlib -n GradingSystem.Core
dotnet new xunit -n GradingSystem.Tests
dotnet new console -n GradingSystem.App
dotnet sln add GradingSystem.Core GradingSystem.Tests GradingSystem.App
dotnet add GradingSystem.Tests reference GradingSystem.Core
dotnet add GradingSystem.App reference GradingSystem.Core
```
Xóa `Class1.cs` (Core) và `UnitTest1.cs` (Tests), rồi chép các file .cs trong zip này vào đúng thư mục.

## Chạy test
```bash
dotnet test
```
